import java.awt.*;

import interfaces.IFont.FontType;

public class Bold implements interfaces.IFont {



	public FontType getFontType() {
		return FontType.Bold;
	}

}
