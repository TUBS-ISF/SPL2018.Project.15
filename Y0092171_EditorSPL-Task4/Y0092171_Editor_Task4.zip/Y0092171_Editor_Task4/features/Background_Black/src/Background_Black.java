import java.awt.*;

public class Background_Black implements interfaces.IColor {


	public Color getColor() {
		return Color.BLACK;
	}
		
	public interfaces.IColor.ColorType getColorType() {
		return interfaces.IColor.ColorType.Background;
	}	

}
