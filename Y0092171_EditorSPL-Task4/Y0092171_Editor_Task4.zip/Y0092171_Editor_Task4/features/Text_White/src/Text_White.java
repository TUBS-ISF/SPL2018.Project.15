import java.awt.*;

public class Text_White implements interfaces.IColor {

	public Color getColor() {
		return Color.WHITE;
	}
		
	public ColorType getColorType() {
		return ColorType.Text;
	}
	

}
