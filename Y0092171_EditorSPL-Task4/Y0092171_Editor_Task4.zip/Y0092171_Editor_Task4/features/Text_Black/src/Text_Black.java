import java.awt.*;

public class Text_Black implements interfaces.IColor {

	public Color getColor() {
		return Color.BLACK;
	}
		
	public ColorType getColorType() {
		return ColorType.Text;
	}
	
}
